#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PyPlayer —— 零依赖视频播放器
==============================

思路：Python 负责「管文件、起服务、发数据」，视频交给系统浏览器解码。
      浏览器内核原生支持 MP4/H.264 + 音频，所以不用装任何第三方库。

特性：
  * 播放列表（自动扫描文件夹里的视频）
  * 播放/暂停、拖拽进度、音量、倍速（0.5x ~ 2x）
  * 全屏、上一个/下一个、自动连播
  * 记住每个视频上次看到的位置
  * 支持 Range 请求（所以能随意拖动进度条）
  * 点「添加文件」会弹出系统文件选择框
  * 以无边框「App 模式」窗口打开（看起来就是个独立播放器）

用法：
  python pyplayer.py                  # 扫描桌面和「视频」文件夹
  python pyplayer.py D:\\影片          # 扫描指定文件夹
  python pyplayer.py a.mp4 b.mkv      # 只放这几个文件
"""

import http.server
import json
import mimetypes
import os
import re
import subprocess
import sys
import threading
import time
import urllib.parse
import webbrowser

PORT = 8765
MEDIA_EXTS = {
    # 视频
    ".mp4", ".m4v", ".webm", ".mkv", ".avi", ".mov", ".flv",
    ".wmv", ".mpg", ".mpeg", ".ts", ".m3u8", ".ogv",
    # 音频（播放器会标成"音频·只有声音"）
    ".mp3", ".m4a", ".aac", ".flac", ".wav", ".opus", ".ogg",
}
# 浏览器真正能放的格式（其它格式浏览器可能只出声音或直接报错）
BROWSER_OK = {".mp4", ".m4v", ".webm", ".ogg", ".ogv"}

PLAYLIST = []          # [{"path":..., "name":..., "size":...}]
LOCK = threading.Lock()

# 心跳：页面每 2 秒 ping 一次，超过 20 秒没动静就自动退出（关窗口就退）
PING_STATE = {"last": time.time(), "seen": False, "enabled": False}


# ------------------------------------------------------------------ 媒体列表
def sniff_mime(path):
    """看文件头判断真实类型（有不少 .mp4 其实是 mp3）"""
    try:
        with open(path, "rb") as f:
            head = f.read(16)
    except OSError:
        return "application/octet-stream", "video"
    if head[:3] == b"ID3":
        return "audio/mpeg", "audio"
    if head[:4] == b"fLaC":
        return "audio/flac", "audio"
    if head[:4] == b"OggS":
        return "audio/ogg", "audio"
    if head[:4] == b"RIFF" and head[8:12] == b"WAVE":
        return "audio/wav", "audio"
    if len(head) >= 12 and head[4:8] == b"ftyp":
        return "video/mp4", "video"
    if head[:4] == b"\x1aE\xdf\xa3":
        return "video/webm", "video"
    return mimetypes.guess_type(path)[0] or "application/octet-stream", "video"


def add_path(p, depth=1):
    """depth<=0 时不进入子目录；depth=1 只看这一层；更大的值继续往下挖"""
    p = os.path.abspath(p)
    if os.path.isdir(p):
        if depth <= 0:
            return 0
        try:
            names = sorted(os.listdir(p))
        except OSError:
            return 0
        n = 0
        for nm in names:
            n += add_path(os.path.join(p, nm), depth - 1)
        return n
    if os.path.isfile(p) and os.path.splitext(p)[1].lower() in MEDIA_EXTS:
        with LOCK:
            if any(x["path"] == p for x in PLAYLIST):
                return 0
            mime, kind = sniff_mime(p)
            PLAYLIST.append({
                "path": p,
                "name": os.path.basename(p),
                "size": os.path.getsize(p),
                "mime": mime,
                "kind": kind,
            })
        return 1
    return 0


def scan_defaults():
    """默认扫桌面、视频、音乐三个文件夹（音乐里的 mp3 会用咕咕鸡舞台播）"""
    home = os.path.expanduser("~")
    for d in (os.path.join(home, "Desktop"),
              os.path.join(home, "Videos"),
              os.path.join(home, "Music")):
        if os.path.isdir(d):
            add_path(d)


# ------------------------------------------------------------------ HTTP 处理
class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "PyPlayer/1.0"

    def log_message(self, fmt, *args):
        pass  # 安静模式

    # ---------- 小工具 ----------
    def _send(self, code, body=b"", ctype="text/plain; charset=utf-8", extra=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if extra:
            for k, v in extra.items():
                self.send_header(k, v)
        self.end_headers()
        if body and self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionAbortedError):
                pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8")

    # ---------- 路由 ----------
    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path

        if path in ("/", "/index.html"):
            return self._send(200, PAGE.encode("utf-8"), "text/html; charset=utf-8")

        if path == "/api/list":
            with LOCK:
                items = []
                for i, it in enumerate(PLAYLIST):
                    ext = os.path.splitext(it["name"])[1].lower()
                    items.append({
                        "id": i,
                        "name": it["name"],
                        "size": it["size"],
                        "ok": ext in BROWSER_OK,
                        "ext": ext.lstrip("."),
                        "kind": it.get("kind", "video"),
                    })
            return self._json({"items": items})

        if path == "/api/pick":
            return self._json({"items": self._pick_files()})

        if path == "/api/ping":
            PING_STATE["seen"] = True
            PING_STATE["last"] = time.time()
            return self._json({"ok": True})

        if path == "/api/quit":
            self._json({"ok": True})
            threading.Timer(0.3, lambda: os._exit(0)).start()
            return

        m = re.match(r"^/media/(\d+)$", path)
        if m:
            return self._serve_media(int(m.group(1)))

        return self._send(404, b"not found")

    # ---------- 打开文件选择框 ----------
    def _pick_files(self):
        files = []
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            files = filedialog.askopenfilenames(
                title="选择要播放的文件",
                filetypes=[
                    ("音视频文件", "*.mp4 *.m4v *.webm *.mkv *.avi *.mov *.flv *.wmv *.ts "
                                 "*.mp3 *.m4a *.aac *.flac *.wav *.ogg *.opus"),
                    ("视频文件", "*.mp4 *.m4v *.webm *.mkv *.avi *.mov *.flv *.wmv *.ts"),
                    ("音频文件", "*.mp3 *.m4a *.aac *.flac *.wav *.ogg *.opus"),
                    ("所有文件", "*.*"),
                ],
            )
            root.destroy()
        except Exception as e:      # noqa: BLE001
            print("文件选择框打不开:", e)
        added = 0
        for f in files:
            added += add_path(f)
        print(f"[pick] 选择了 {len(files)} 个，新增 {added} 个")
        with LOCK:
            return [{"id": i, "name": it["name"], "size": it["size"]}
                    for i, it in enumerate(PLAYLIST)]

    # ---------- 视频数据（支持 Range）----------
    def _serve_media(self, idx):
        with LOCK:
            if idx < 0 or idx >= len(PLAYLIST):
                return self._send(404, b"no such media")
            item = PLAYLIST[idx]
        path = item["path"]
        if not os.path.isfile(path):
            return self._send(404, b"file gone")

        size = os.path.getsize(path)
        ctype = item.get("mime") or mimetypes.guess_type(path)[0] or "application/octet-stream"
        rng = self.headers.get("Range", "")

        start, end = 0, size - 1
        partial = False
        if rng.startswith("bytes="):
            a, _, b = rng[6:].partition("-")
            try:
                if a:
                    start = int(a)
                    end = int(b) if b else size - 1
                elif b:                       # bytes=-500 → 最后 500 字节
                    start = max(0, size - int(b))
                start = max(0, min(start, size - 1))
                end = max(start, min(end, size - 1))
                partial = True
            except ValueError:
                start, end, partial = 0, size - 1, False

        length = end - start + 1
        try:
            f = open(path, "rb")
        except OSError:
            return self._send(403, b"cannot open")

        with f:
            f.seek(start)
            self.send_response(206 if partial else 200)
            self.send_header("Content-Type", ctype)
            self.send_header("Accept-Ranges", "bytes")
            self.send_header("Content-Length", str(length))
            if partial:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.end_headers()
            if self.command == "HEAD":
                return
            remaining = length
            chunk = 1024 * 256
            try:
                while remaining > 0:
                    data = f.read(min(chunk, remaining))
                    if not data:
                        break
                    self.wfile.write(data)
                    remaining -= len(data)
            except (BrokenPipeError, ConnectionAbortedError, ConnectionResetError):
                pass      # 用户拖动了进度条，客户端主动断开，正常现象


# ------------------------------------------------------------------ 启动浏览器
def open_app_window(url):
    """优先用 Edge/Chrome 的 --app 模式（无地址栏，像个独立播放器）"""
    candidates = [
        os.path.join(os.environ.get("ProgramFiles(x86)", ""), r"Microsoft\Edge\Application\msedge.exe"),
        os.path.join(os.environ.get("ProgramFiles", ""), r"Microsoft\Edge\Application\msedge.exe"),
        os.path.join(os.environ.get("LocalAppData", ""), r"Microsoft\Edge\Application\msedge.exe"),
        os.path.join(os.environ.get("ProgramFiles", ""), r"Google\Chrome\Application\chrome.exe"),
        os.path.join(os.environ.get("ProgramFiles(x86)", ""), r"Google\Chrome\Application\chrome.exe"),
    ]
    for exe in candidates:
        if exe and os.path.isfile(exe):
            try:
                subprocess.Popen([
                    exe,
                    f"--app={url}",
                    "--start-maximized",
                    "--disable-features=Translate",
                    f"--user-data-dir={os.path.join(os.environ.get('TEMP', '.'), 'pyplayer_profile')}",
                ])
                print("已用 App 模式打开:", exe)
                return True
            except OSError as e:
                print("启动失败:", e)
    print("没找到 Edge/Chrome，改用默认浏览器")
    webbrowser.open(url)
    return False


def probe_port(port):
    import socket
    for p in range(port, port + 30):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", p))
            s.close()
            return p
        except OSError:
            s.close()
    return port


# ------------------------------------------------------------------ 主程序
def main():
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if args:
        total = 0
        for a in args:
            total += add_path(a, 4)
        print(f"从命令行添加了 {total} 个视频")
    if not PLAYLIST:
        scan_defaults()

    global PORT
    PORT = probe_port(PORT)
    url = f"http://127.0.0.1:{PORT}/"

    with LOCK:
        print(f"共 {len(PLAYLIST)} 个视频:")
        for i, it in enumerate(PLAYLIST[:12]):
            print(f"  [{i}] {it['name']}")
        if len(PLAYLIST) > 12:
            print(f"  ... 还有 {len(PLAYLIST) - 12} 个")

    httpd = http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()

    # 看门狗：页面停止心跳 20 秒 → 自动退出
    PING_STATE["enabled"] = True

    def _watchdog():
        while True:
            time.sleep(3)
            if (PING_STATE["enabled"] and PING_STATE["seen"]
                    and time.time() - PING_STATE["last"] > 20):
                print("播放器窗口已关闭，退出。")
                os._exit(0)

    threading.Thread(target=_watchdog, daemon=True).start()

    print(f"\n服务已启动: {url}")
    print("关闭这个窗口就退出播放器。\n")

    if "--no-open" not in sys.argv:
        open_app_window(url)
    else:
        print("(测试模式：不自动打开窗口)")

    try:
        while True:
            threading.Event().wait(1)
    except KeyboardInterrupt:
        print("退出。")
        httpd.shutdown()


# ------------------------------------------------------------------ 前端页面
PAGE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>PyPlayer</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  :root{--bg:#0b1017;--panel:#141b26;--line:#222e3d;--fg:#e8f1fb;--dim:#7f93aa;--acc:#37b6ff}
  html,body{height:100%}
  body{
    background:var(--bg);color:var(--fg);
    font-family:"Microsoft YaHei","Segoe UI",system-ui,sans-serif;
    display:flex;overflow:hidden;user-select:none;
  }
  /* ---- 播放列表 ---- */
  #side{
    width:300px;flex:0 0 300px;background:var(--panel);border-right:1px solid var(--line);
    display:flex;flex-direction:column;transition:margin-left .22s;
  }
  #side.hide{margin-left:-300px}
  #side header{
    padding:14px 16px;border-bottom:1px solid var(--line);
    display:flex;align-items:center;gap:8px;
  }
  #side h1{font-size:15px;font-weight:700;letter-spacing:.5px}
  #side h1 span{color:var(--acc)}
  #count{font-size:11px;color:var(--dim);margin-left:auto}
  #list{flex:1;overflow-y:auto;padding:8px}
  #list::-webkit-scrollbar{width:8px}
  #list::-webkit-scrollbar-thumb{background:#2a3648;border-radius:4px}
  .item{
    padding:9px 11px;border-radius:9px;cursor:pointer;margin-bottom:3px;
    display:flex;gap:9px;align-items:flex-start;line-height:1.35;
  }
  .item:hover{background:#1c2532}
  .item.on{background:linear-gradient(90deg,#12344d,#16283a);box-shadow:inset 2px 0 0 var(--acc)}
  .idx{font-size:11px;color:var(--dim);min-width:18px;padding-top:2px}
  .nm{font-size:13px;word-break:break-all}
  .meta{font-size:10.5px;color:var(--dim);margin-top:2px}
  .bad{color:#e0a04a}
  #add{
    margin:8px;padding:11px;border:1px dashed #33475e;border-radius:10px;
    text-align:center;font-size:13px;color:#9db4cc;cursor:pointer;
  }
  #add:hover{border-color:var(--acc);color:var(--acc)}
  /* ---- 主区域 ---- */
  #main{flex:1;display:flex;flex-direction:column;min-width:0;position:relative}
  #stage{flex:1;display:flex;align-items:center;justify-content:center;background:#000;position:relative;overflow:hidden}
  video{max-width:100%;max-height:100%;width:100%;height:100%;object-fit:contain;background:#000}
  #empty{
    position:absolute;text-align:center;color:var(--dim);font-size:14px;line-height:2;
  }
  #empty b{color:var(--fg);font-size:17px;display:block;margin-bottom:6px}
  #toggleSide{
    position:absolute;left:12px;top:12px;z-index:5;width:34px;height:34px;border-radius:8px;
    background:rgba(10,16,24,.55);border:1px solid rgba(255,255,255,.12);color:#cfe3f5;
    cursor:pointer;font-size:15px;line-height:1;
  }
  #toggleSide:hover{background:rgba(55,182,255,.25)}
  /* ---- 控制条 ---- */
  #ctl{
    background:linear-gradient(180deg,#101721,#0d141c);border-top:1px solid var(--line);
    padding:10px 16px 14px;
  }
  #bar{
    height:6px;background:#243040;border-radius:3px;cursor:pointer;position:relative;margin-bottom:9px;
  }
  #bar:hover{height:9px;margin-bottom:6px}
  #fill{height:100%;width:0;background:linear-gradient(90deg,#2d8fd0,var(--acc));border-radius:3px;position:relative}
  #dot{
    position:absolute;right:-7px;top:50%;width:14px;height:14px;margin-top:-7px;border-radius:50%;
    background:#fff;box-shadow:0 0 8px rgba(55,182,255,.8);opacity:0;transition:opacity .15s;
  }
  #bar:hover #dot{opacity:1}
  #row{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
  button{
    background:#1b2533;border:1px solid #2a3a4d;color:var(--fg);border-radius:8px;
    padding:7px 13px;font-size:13px;cursor:pointer;font-family:inherit;
  }
  button:hover{border-color:var(--acc);color:var(--acc)}
  button.main{background:linear-gradient(180deg,#2c94d6,#1f76b4);border-color:#3aa6e8;font-weight:700;min-width:78px}
  button.main:hover{filter:brightness(1.12);color:#fff}
  #time{font-size:12.5px;color:var(--dim);font-variant-numeric:tabular-nums}
  #time b{color:var(--fg)}
  .grp{display:flex;align-items:center;gap:6px}
  input[type=range]{
    -webkit-appearance:none;width:92px;height:4px;border-radius:2px;background:#2b3a4d;outline:none;
  }
  input[type=range]::-webkit-slider-thumb{
    -webkit-appearance:none;width:13px;height:13px;border-radius:50%;background:#dfeaf6;cursor:pointer;
  }
  select{
    background:#1b2533;border:1px solid #2a3a4d;color:var(--fg);border-radius:8px;
    padding:7px 9px;font-size:12.5px;font-family:inherit;cursor:pointer;
  }
  .spacer{flex:1}
  #title{font-size:12.5px;color:#9db4cc;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:38vw}
  /* ---- 拖放 ---- */
  #drop{
    position:fixed;inset:0;background:rgba(8,14,22,.86);z-index:99;
    display:none;align-items:center;justify-content:center;font-size:22px;color:var(--acc);
    border:3px dashed var(--acc);
  }
  #drop.on{display:flex}

  /* ---- 咕咕鸡跳舞（音频模式专属舞台）---- */
  #chicken{
    position:absolute; inset:0; display:none;
    align-items:center; justify-content:center;
    pointer-events:none; overflow:hidden;
    background: radial-gradient(circle at 50% 62%, #1b2a3d 0%, #0b1118 70%);
  }
  #chicken.on{display:flex}
  #chicken .wrap{
    position:relative; height:74%;
    transform: scale(calc(1 + var(--b, 0) * 0.12));
    transition: transform .07s linear;
  }
  #chicken svg{height:100%; width:auto; display:block;
    filter: drop-shadow(0 14px 26px rgba(0,0,0,.55))}
  .cg-body{animation: ggBob .52s ease-in-out infinite alternate; transform-origin:104px 190px}
  .cg-wing{animation: ggFlap .34s ease-in-out infinite alternate; transform-origin:100px 116px}
  .cg-head{animation: ggNod .52s ease-in-out infinite alternate; transform-origin:138px 96px}
  @keyframes ggBob{from{transform:translateY(0) rotate(-2.5deg)}to{transform:translateY(-11px) rotate(3deg)}}
  @keyframes ggFlap{from{transform:rotate(-16deg)}to{transform:rotate(20deg)}}
  @keyframes ggNod{from{transform:rotate(-7deg)}to{transform:rotate(8deg)}}
  #chicken .notes{
    position:absolute; right:-14%; bottom:38%;
    font-size:clamp(18px,3.2vh,32px); color:#7fd1ff;
  }
  #chicken .notes span{display:inline-block; margin:0 5px; animation: ggNote 2.3s linear infinite}
  #chicken .notes span:nth-child(2){animation-delay:.75s; color:#c39bff}
  #chicken .notes span:nth-child(3){animation-delay:1.5s}
  @keyframes ggNote{
    0%{transform:translateY(0) scale(.7); opacity:0}
    18%{opacity:.95}
    100%{transform:translateY(-110px) scale(1.3); opacity:0}
  }
  /* 暂停时把舞步定住，别让它一直跳 */
  #chicken.paused .cg-body,#chicken.paused .cg-wing,#chicken.paused .cg-head,
  #chicken.paused .notes span{animation-play-state:paused}
/* ---- 启动动画 ---- */
#splash{
  position:fixed; inset:0; z-index:9999;
  display:flex; align-items:center; justify-content:center;
  background:radial-gradient(circle at 50% 42%, #1b2740 0%, #0a0f16 68%);
  transition: opacity .5s ease;
}
#splash.out{opacity:0; pointer-events:none}
#splash .sp-box{display:flex; flex-direction:column; align-items:center; gap:22px}
#splash .sp-ico{
  width:clamp(96px, 15vh, 150px); height:auto;
  animation: spPop .62s cubic-bezier(.2,1.5,.45,1) both;
  filter: drop-shadow(0 12px 32px rgba(80,150,255,.35));
}
@keyframes spPop{
  0%{transform:scale(.2) translateY(24px); opacity:0}
  60%{transform:scale(1.08) translateY(0); opacity:1}
  100%{transform:scale(1)}
}
#splash .sp-row{
  display:flex; align-items:center; gap:12px;
  animation: spFade .35s ease both;
}
#splash .sp-txt{
  font-size:clamp(15px,2.3vh,20px); letter-spacing:6px; color:#cfe3f7;
}
#splash .sp-ring{
  width:20px; height:20px; border-radius:50%;
  border:2.5px solid rgba(160,200,240,.22);
  border-top-color:#7fd1ff; border-right-color:#a86bff;
  animation: spSpin .75s linear infinite;
}
@keyframes spSpin{to{transform:rotate(360deg)}}
#splash .sp-brand{
  font-size:clamp(11px,1.6vh,13px); letter-spacing:3px;
  color:#5f7993; animation: spFade .4s ease .12s both;
}
@keyframes spFade{from{opacity:0; transform:translateY(6px)}to{opacity:1; transform:none}}
</style>
</head>
<body>
<div id="splash">
  <div class="sp-box">
    <svg class="sp-ico" viewBox="0 0 256 256" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="spg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="#7c3ebe"/>
          <stop offset="1" stop-color="#3096e4"/>
        </linearGradient>
      </defs>
      <rect x="0" y="0" width="256" height="256" rx="56" fill="url(#spg)"/>
      <circle cx="128" cy="128" r="80" fill="none" stroke="#ffffff" stroke-width="15"/>
      <polygon points="92,76 92,180 196,128" fill="#ffffff"/>
    </svg>
    <div class="sp-row">
      <span class="sp-txt">启动中</span>
      <span class="sp-ring"></span>
    </div>
    <div class="sp-brand">咕咕鸡播放器</div>
  </div>
</div>
<div id="side">
  <header>
    <h1>Py<span>Player</span></h1>
    <div id="count"></div>
  </header>
  <div id="list"></div>
  <div id="add">+ 添加文件（视频 / 音乐）…</div>
</div>

<div id="main">
  <div id="stage">
    <video id="v" preload="metadata"></video>
    <div id="chicken">
      <div class="wrap">
        <svg viewBox="0 0 220 230" xmlns="http://www.w3.org/2000/svg">
          <ellipse cx="108" cy="215" rx="54" ry="9" fill="#000" opacity=".35"/>
          <g class="cg-body">
            <path d="M88 172 l-6 26 M120 172 l6 26" stroke="#f5a623" stroke-width="8" stroke-linecap="round" fill="none"/>
            <path d="M82 198 l-13 6 M82 198 l13 6 M126 198 l-13 6 M126 198 l13 6" stroke="#f5a623" stroke-width="6" stroke-linecap="round" fill="none"/>
            <path d="M46 106 q-32 -22 -40 3 q23 4 33 19 z" fill="#f2f2f2"/>
            <ellipse cx="104" cy="124" rx="64" ry="56" fill="#ffffff"/>
            <g class="cg-wing">
              <path d="M96 116 q23 -15 46 2 q-17 27 -46 13 z" fill="#ededed" stroke="#dedede" stroke-width="2"/>
            </g>
            <g class="cg-head">
              <circle cx="146" cy="64" r="35" fill="#ffffff"/>
              <path d="M127 35 q4 -17 15 -5 q5 -16 14 -5 q6 -13 11 7 q-21 10 -40 3 z" fill="#e5484d"/>
              <path d="M177 60 l23 7 l-23 9 z" fill="#f5a623"/>
              <path d="M175 73 q6 12 1 17 q-9 -2 -10 -12 z" fill="#e5484d"/>
              <circle cx="159" cy="56" r="5.5" fill="#121212"/>
              <path d="M150 66 q11 6 19 0" stroke="#e5484d" stroke-width="3" fill="none" stroke-linecap="round"/>
            </g>
          </g>
        </svg>
        <div class="notes"><span>♪</span><span>♫</span><span>♪</span></div>
      </div>
    </div>
    <div id="empty"><b>选一个文件开始播放</b>左侧点文件 · 或把文件拖进窗口</div>
    <button id="toggleSide" title="显示/隐藏列表">☰</button>
  </div>

  <div id="ctl">
    <div id="bar"><div id="fill"><div id="dot"></div></div></div>
    <div id="row">
      <button class="main" id="play">▶ 播放</button>
      <button id="prev" title="上一个">⏮</button>
      <button id="next" title="下一个">⏭</button>
      <div id="time"><b>0:00</b> / 0:00</div>
      <div class="grp">
        <button id="mute" title="静音">🔊</button>
        <input type="range" id="vol" min="0" max="100" value="100">
      </div>
      <select id="speed" title="播放速度">
        <option value="0.5">0.5x</option>
        <option value="0.75">0.75x</option>
        <option value="1" selected>1.0x</option>
        <option value="1.25">1.25x</option>
        <option value="1.5">1.5x</option>
        <option value="2">2.0x</option>
      </select>
      <div class="spacer"></div>
      <div id="title"></div>
      <button id="fs" title="全屏 (F)">⛶ 全屏</button>
      <button id="quit" title="退出播放器">⏻ 退出</button>
    </div>
  </div>
</div>

<div id="drop">松开鼠标，添加这些文件</div>

<script>
const v = document.getElementById('v');
const $ = id => document.getElementById(id);
let items = [], cur = -1;

/* ---------- 列表 ---------- */
async function loadList() {
  const r = await fetch('/api/list');
  const d = await r.json();
  items = d.items || [];
  $('count').textContent = items.length + ' 个文件';
  const box = $('list');
  box.innerHTML = '';
  items.forEach(it => {
    const el = document.createElement('div');
    el.className = 'item' + (it.id === cur ? ' on' : '');
    el.dataset.id = it.id;
    const mb = (it.size / 1048576).toFixed(1);
    const isAudio = it.kind === 'audio';
    const tag = isAudio ? '<span style="color:#7fd1ff">音频</span>' : it.ext.toUpperCase();
    const warn = isAudio ? ' <span style="color:#7fd1ff">咕咕鸡跳舞</span>'
                         : (it.ok ? '' : ' <span class="bad">可能不支持</span>');
    el.innerHTML = '<div class="idx">' + (it.id + 1) + '</div>' +
      '<div style="min-width:0"><div class="nm">' + esc(it.name) + '</div>' +
      '<div class="meta">' + tag + ' · ' + mb + ' MB' + warn + '</div></div>';
    el.onclick = () => play(it.id);
    box.appendChild(el);
  });
  if (cur < 0 && items.length) play(0, false);   // 只选中，不自动播
}
function esc(s){return s.replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}

/* ---------- 播放 ---------- */
function play(id, auto) {
  if (id < 0 || id >= items.length) return;
  if (auto === undefined) auto = true;
  cur = id;
  const it = items[id];
  v.src = '/media/' + id;
  if (auto) v.play().catch(()=>{});
  $('empty').style.display = 'none';          // 关键：把提示遮罩藏起来
  // ---- 音频 → 咕咕鸡跳舞；视频 → 隐藏 ----
  const isAudioNow = (it.kind === 'audio');
  $('chicken').classList.toggle('on', isAudioNow);
  if (isAudioNow) {
    initAudioGraph();
    if (AC && AC.state === 'suspended') AC.resume().catch(() => {});
    if (!rafId) beatLoop();
  } else {
    if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
    $('chicken').style.setProperty('--b', '0');
  }
  $('title').textContent = it.name;
  document.title = it.name + ' — PyPlayer';
  document.querySelectorAll('.item').forEach(e =>
    e.classList.toggle('on', +e.dataset.id === id));
}
v.addEventListener('loadedmetadata', () => {
  const it = items[cur];
  if (it) {
    const rest = localStorage.getItem('pos:' + it.name);
    if (rest && parseFloat(rest) < v.duration - 5) v.currentTime = parseFloat(rest);
  }
});
let saveT = 0;
v.addEventListener('timeupdate', () => {
  const it = items[cur];
  if (!it) return;
  const now = Date.now();
  if (now - saveT > 2000) { saveT = now; localStorage.setItem('pos:' + it.name, v.currentTime); }
  const p = v.duration ? v.currentTime / v.duration * 100 : 0;
  $('fill').style.width = p + '%';
  $('time').innerHTML = '<b>' + fmt(v.currentTime) + '</b> / ' + fmt(v.duration || 0);
});
v.addEventListener('ended', () => { if (cur + 1 < items.length) play(cur + 1); });
v.addEventListener('play', () => {
  $('play').textContent = '⏸ 暂停';
  $('chicken').classList.remove('paused');
  // 关键：Web Audio 接管后，AudioContext 若仍挂起就会没声音，每次播放都试着恢复
  if (AC && AC.state === 'suspended') AC.resume().catch(() => {});
});
v.addEventListener('pause', () => {
  $('play').textContent = '▶ 播放';
  $('chicken').classList.add('paused');
});

/* ---------- 咕咕鸡：音频节奏分析（Web Audio） ---------- */
let AC = null, AN = null, SRC_NODE = null, rafId = 0;
function initAudioGraph() {
  if (SRC_NODE) return;                       // 只能创建一次
  try {
    AC = new (window.AudioContext || window.webkitAudioContext)();
    AN = AC.createAnalyser();
    AN.fftSize = 512;
    AN.smoothingTimeConstant = 0.72;
    SRC_NODE = AC.createMediaElementSource(v);
    SRC_NODE.connect(AN);
    AN.connect(AC.destination);               // 必须接回扬声器，否则没声音
  } catch (e) {
    AC = null; AN = null; SRC_NODE = null;
  }
}
function beatLoop() {
  if (!AN) return;
  const buf = new Uint8Array(AN.frequencyBinCount);
  AN.getByteFrequencyData(buf);
  let sum = 0;
  for (let i = 0; i < 12; i++) sum += buf[i];   // 低频 ≈ 20~250Hz，鼓点在这
  const e = Math.min(1, (sum / 12) / 170);
  $('chicken').style.setProperty('--b', e.toFixed(3));
  rafId = requestAnimationFrame(beatLoop);
}

function fmt(s) {
  s = Math.max(0, Math.floor(s || 0));
  const m = Math.floor(s / 60), ss = s % 60;
  return m + ':' + (ss < 10 ? '0' : '') + ss;
}

/* ---------- 控制 ---------- */
$('play').onclick = () => { if (!v.src && items.length) return play(0); v.paused ? v.play() : v.pause(); };
$('prev').onclick = () => play(Math.max(0, cur - 1));
$('next').onclick = () => play(Math.min(items.length - 1, cur + 1));
$('vol').oninput = e => { v.volume = e.target.value / 100; v.muted = false; $('mute').textContent = '🔊'; };
$('mute').onclick = () => { v.muted = !v.muted; $('mute').textContent = v.muted ? '🔇' : '🔊'; };
$('speed').onchange = e => v.playbackRate = parseFloat(e.target.value);
$('fs').onclick = () => {
  if (document.fullscreenElement) document.exitFullscreen();
  else document.documentElement.requestFullscreen();
};
$('bar').onclick = e => {
  if (!v.duration) return;
  const r = e.currentTarget.getBoundingClientRect();
  v.currentTime = (e.clientX - r.left) / r.width * v.duration;
};
$('toggleSide').onclick = () => $('side').classList.toggle('hide');
$('add').onclick = async () => {
  $('add').textContent = '选择中…';
  await fetch('/api/pick');
  $('add').textContent = '+ 添加文件（视频 / 音乐）…';
  await loadList();
};

/* ---------- 键盘 ---------- */
document.addEventListener('keydown', e => {
  if (e.target.tagName === 'SELECT' || e.target.tagName === 'INPUT') return;
  switch (e.key.toLowerCase()) {
    case ' ': case 'k': e.preventDefault(); $('play').click(); break;
    case 'arrowright': v.currentTime += 5; break;
    case 'arrowleft': v.currentTime -= 5; break;
    case 'arrowup': e.preventDefault(); v.volume = Math.min(1, v.volume + .1); $('vol').value = v.volume * 100; break;
    case 'arrowdown': e.preventDefault(); v.volume = Math.max(0, v.volume - .1); $('vol').value = v.volume * 100; break;
    case 'f': $('fs').click(); break;
    case 'n': $('next').click(); break;
    case 'p': $('prev').click(); break;
    case 'm': $('mute').click(); break;
    case 'l': $('toggleSide').click(); break;
  }
});

/* ---------- 拖放 ---------- */
const drop = $('drop');
['dragenter','dragover'].forEach(t => document.addEventListener(t, e => { e.preventDefault(); drop.classList.add('on'); }));
['dragleave','drop'].forEach(t => document.addEventListener(t, e => {
  e.preventDefault();
  if (t === 'drop' || e.relatedTarget === null) drop.classList.remove('on');
}));
document.addEventListener('drop', e => {
  const files = e.dataTransfer && e.dataTransfer.files;
  if (!files || !files.length) return;
  const f = files[0];
  const okName = /\.(mp4|m4v|webm|mkv|avi|mov|flv|wmv|ogg|ogv|mp3|m4a|aac|flac|wav|opus)$/i.test(f.name);
  const isAudioFile = f.type.startsWith('audio/') || /\.(mp3|m4a|aac|flac|wav|opus)$/i.test(f.name);
  if (!f.type.startsWith('video/') && !isAudioFile && !okName) return;
  v.src = URL.createObjectURL(f);      // 本地直接播，不用上传
  v.play().catch(()=>{});
  $('empty').style.display = 'none';
  $('chicken').classList.toggle('on', isAudioFile);
  if (isAudioFile) {
    initAudioGraph();
    if (AC && AC.state === 'suspended') AC.resume().catch(() => {});
    if (!rafId) beatLoop();
  } else {
    if (rafId) { cancelAnimationFrame(rafId); rafId = 0; }
    $('chicken').style.setProperty('--b', '0');
  }
  $('title').textContent = f.name + '（拖入播放中）';
  document.title = f.name + ' — PyPlayer';
});

v.addEventListener('error', () => {
  const it = items[cur];
  if (it) $('title').textContent = it.name + '  —— 这个格式浏览器放不了，试试 MP4/WebM';
});

loadList();

/* ?autoplay=1 直接播第一个；?sel=N 选中第 N 个（都方便自动化测试） */
const _q = new URLSearchParams(location.search);
setTimeout(() => {
  const sel = parseInt(_q.get('sel') || '', 10);
  if (!isNaN(sel) && items.length) {
    play(Math.min(Math.max(sel, 0), items.length - 1), _q.get('autoplay') === '1');
    return;
  }
  if (_q.get('autoplay') === '1' && items.length) play(0, true);
}, 400);

/* 心跳：关掉这个窗口后，后台 Python 会在 20 秒内自动退出 */
setInterval(() => { fetch('/api/ping').catch(()=>{}); }, 2000);
fetch('/api/ping').catch(()=>{});

/* 退出按钮 */
document.getElementById('quit').onclick = () => {
  fetch('/api/quit').catch(()=>{});
  setTimeout(() => window.close(), 200);
};/* ---------- 启动动画：列表就绪后收起 ---------- */
(function splashGuard() {
  const t0 = Date.now();
  let done = false;
  function hide() {
    if (done) return;
    done = true;
    const el = document.getElementById('splash');
    if (!el) return;
    const wait = Math.max(0, 1600 - (Date.now() - t0));   // 至少露 1.6 秒
    setTimeout(function () {
      el.classList.add('out');
      setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 560);
    }, wait);
  }
  const iv = setInterval(function () {
    const cnt = document.getElementById('count');
    if ((cnt && cnt.textContent) || document.querySelectorAll('#list .item').length) {
      clearInterval(iv);
      hide();
    }
  }, 100);
  setTimeout(function () { clearInterval(iv); hide(); }, 4500);   // 兜底
})();

</script>
</body>
</html>
"""

if __name__ == "__main__":
    main()
